Install plugin for git connection
	http://download.eclipse.org/egit/updates
	